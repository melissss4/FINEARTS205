let x = 0 ;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(100, 100, 10);
  
  fill(150, 0, 100);
  rect(mouseX, mouseY, 40, 60)
  
  x= x + 3


}
